<?php
/**
 * Cue the star of the show...
 *
 * @package Thesis
 */
thesis_html_framework();
?>