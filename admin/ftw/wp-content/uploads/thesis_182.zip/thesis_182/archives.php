<?php
/**
 * Template Name: Archives
 *
 * An archives template for pages which outputs category and monthly listings.
 * Can be customized via the thesis_hook_archives_template() hook.
 *
 * @package Thesis
 */

thesis_html_framework();