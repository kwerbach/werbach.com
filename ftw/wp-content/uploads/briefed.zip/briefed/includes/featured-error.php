<div id="slides" class="col-full">
	
	<p class="woo-sc-box note"><?php _e('Please setup Slider Panel tag(s) in your options panel. You must setup tags that are used on active portfolio posts.','woothemes'); ?></p>
	
</div><!-- /.slides -->