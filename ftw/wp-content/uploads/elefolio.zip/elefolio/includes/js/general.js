jQuery(document).ready(function() {

	// Column heights
	var content;
	content = jQuery("#main").height();
	
	var sidebar;
	sidebar = jQuery("#sidebar").height();

	var tabs;
	tabs = jQuery("#sidebar #tabs").height();
	tabs = tabs/3*2;
	sidebar = sidebar-tabs;
	
	if(content < sidebar){
		jQuery("#main").height(sidebar);
	}
	if(content > sidebar){
		jQuery("#sidebar").height(content);
	}

});