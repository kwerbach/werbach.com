<div id="sidebar" class="fr">

	<?php if (woo_active_sidebar('primary')) : ?>

		<?php woo_sidebar('primary'); ?>		           

	<?php endif; ?>
	
</div><!-- /#sidebar -->